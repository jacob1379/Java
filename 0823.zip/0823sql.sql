drop table board;
drop table review;
create table board(
    mno number(7) constraint board_pk_mno primary key,
    manufacturer varchar2(20char),
    productName varchar2(20char),
    explainM clob,
    price number(10),
    resistrationDate date default sysdate,
    purchaseCnt number(5) default 0,
    reviewCnt number(3) default 0
);

create table review(
    rno number(6),
    content varchar2(200),
    writer varchar2(10),
    writeTime date default sysdate,
    score number(1),
    mno number(6)
);

---------------------

create table product(
    productNo number(7) constraint product_pk_productNo primary key,
    vendor varchar2(10char),
    name varchar2(50char),
    info clob,
    price number(7),
    resisterDay date default sysdate,
    buyCount number(7) default 0,
    reviewCount number(7) default 0
);

create table review(
    reviewNo number(7) constraint review_pk_reviewNo primary key,
    content varchar2(100 char),
    writer varchar2(10 char),
    writeTime date default sysdate,
    star number(1),
    productNo number(6)
);

select * from tab;

-- ��ǰ insert 
    insert into product(productNo,vendor,name,info,price)
    values(1,'������','��������','������ ��������',2600);
    insert into product(productNo,vendor,name,info,price)
    values(2,'�Ե�','��������','������ ��������',2800);
    commit;
-- ���� insert
    insert into review values(1,'����1','spring',sysdate,3,1);
    insert into review values(2,'����1','spring',sysdate,2,1);
    insert into review values(3,'����1','spring',sysdate,4,1);
    commit;
    
-- findById : ���並 ������ ��ǰ����
    select * from product where productNo=1;
    select * from review where productNo=1;
    
    select *
    from product p left outer join review r
    on p.productNo=r.productNo;
    

-- count

-- findAll

-- ����

-- ����

