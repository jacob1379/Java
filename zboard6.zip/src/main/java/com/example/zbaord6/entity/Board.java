package com.example.zbaord6.entity;

import java.util.Date;

import com.example.zboard6.dto.ReadDto;
import com.example.zboard6.dto.UpdateDto;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@EqualsAndHashCode
@ToString
@Builder
public class Board {
	private Integer bno;
	private String title;
	@JsonIgnore
	private String content;
	private String writer;
	private String attachment;
	
	// @Builder를 사용할 경우 인스턴스 초기화가 적용되지 않는다. @Builder.Default 필요
	@Builder.Default
	// Jackson에서 출력할 때 출력형식을 지정하는 어노테이션
	@JsonFormat(pattern="yyyy-MM-dd hh:mm:ss")
	private Date writeTime = new Date();
	
	@Builder.Default
	private Integer readCnt = 0;

	public void init(String uploadUrl, String name, int bno) {
		this.attachment = uploadUrl + name;
		this.bno = bno;
	}
	
	public void init(int bno) {
		this.bno = bno;
	}
	
	public void increaseReadCnt() {
		this.readCnt++;
	}
	
	public void update(UpdateDto dto) {
		this.title = dto.getTitle();
		this.content = dto.getContent();
	}
	public ReadDto toRead() {
		return ReadDto.builder().bno(bno).title(title).content(content).writer(writer).attachment(attachment)
				.writeTime(writeTime).readCnt(readCnt).build();
	}
}
