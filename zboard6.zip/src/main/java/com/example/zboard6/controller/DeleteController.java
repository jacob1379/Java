package com.example.zboard6.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.math.NumberUtils;

import com.icia.zboard6.service.BoardService;

@WebServlet("/board/delete")
public class DeleteController extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String str = request.getParameter("bno");
		int bno = NumberUtils.toInt(str, 0);
		
		BoardService service = BoardService.getInstance();
		boolean result = service.delete(bno);
		
		response.setContentType("text/plain;charset=utf-8");
		if(result==false) {
			response.setStatus(HttpServletResponse.SC_CONFLICT);
			response.getWriter().print("글을 찾을 수 없습니다");
		} else {
			response.getWriter().print(bno + "번 글을 삭제했습니다");
		}
	}
}







