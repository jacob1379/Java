package com.example.zboard6.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.math.NumberUtils;

import com.example.zboard6.dto.Page;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.icia.zboard6.service.BoardService;

@WebServlet("/board/all")
public class ListController extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 출력형식은 json, 출력문자열은 utf-8로 지정
		response.setContentType("application/json;charset=utf-8");

		String str = request.getParameter("pageno");
		// NumberUtils.toInt를 이용해 pageno에 기본값을 지정
		int pageno = NumberUtils.toInt(str, 1);
		
		BoardService service = BoardService.getInstance();
		Page page = service.list(pageno);
		
		String json = new ObjectMapper().writeValueAsString(page);
		response.getWriter().print(json);
	}
}







