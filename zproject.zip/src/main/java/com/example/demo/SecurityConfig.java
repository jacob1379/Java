package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled=true, securedEnabled=true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser("spring").password(passwordEncoder.encode("1234")).roles("USER");
		auth.inMemoryAuthentication().withUser("summer").password(passwordEncoder.encode("1234")).roles("USER");
		auth.inMemoryAuthentication().withUser("winter").password(passwordEncoder.encode("1234")).roles("USER");
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// csrf(웹 페이지 위조를 방지하기 위한 기술.. 필수.. 개발할 때 귀찮아) 끄기 싫음
		http.csrf().disable();
		// mvc 로그인 활성화(자동설정)
		http.formLogin();
		http.logout().logoutUrl("/logout").logoutSuccessUrl("/");
	}
}
