package com.example.demo.contoller;

import java.security.Principal;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.dto.BoardDto;
import com.example.demo.entity.Board;
import com.example.demo.service.BoardService;

@Validated //스프링 검증(없으면 자바 표준검증을 실행, 파라미터 검증이 안되서 스프링검증 사용)
@Controller
public class BoardController {
	@Autowired
	private BoardService service;
	
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/board/write")
	public void write() {
	}
	
	@PreAuthorize("isAuthenticated()")
	@PostMapping("/board/new")
	public ResponseEntity<String> write(@Valid BoardDto.Write dto, BindingResult bindingResult, Principal principal) { //스프링 빈 검증
		Board board = service.write(dto, "spring"); //principal.getName();
		return ResponseEntity.ok("/board/read?bno=" + board.getBno());
	}
	
	@GetMapping("/board/read")
	public void read() {
		
	}
	
	@GetMapping("/board")
	public ResponseEntity<BoardDto.Read> read(Integer bno, Principal principal) {
		String loginId = principal==null? null : principal.getName();
		BoardDto.Read dto = service.read(bno, loginId);
		return ResponseEntity.ok(dto);
	}
}
