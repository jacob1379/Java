package com.example.demo.service;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BoardDao;
import com.example.demo.dto.BoardDto;
import com.example.demo.dto.BoardDto.Read;
import com.example.demo.entity.Board;

@Service
public class BoardService {
	@Autowired
	private BoardDao boardDao;
	
	public Board write(@Valid BoardDto.Write dto, String loginId) {
		Board board = dto.toEntity().addWriter(loginId);
		System.out.println(board);
		System.out.println(dto);
		System.out.println("===================================");
		boardDao.save(board);
		return board;
	}

	public Read read(Integer bno, String loginId) {
		BoardDto.Read dto = boardDao.findById(bno).get();
		return dto;
	}

}
