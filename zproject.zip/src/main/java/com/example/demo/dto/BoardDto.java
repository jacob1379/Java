package com.example.demo.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.example.demo.entity.Comment;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class BoardDto {
	@Data
	public static class ForList {
		private Integer bno;
		private String title;
		private String content;
		private String writer;
		private LocalDateTime writeTime;
		private Integer readCnt;
		private Integer commentCnt;
	}
	// Read는 board, comment 두 테이블을 출력
	// 1. left outer join으로 처리
	// 2. 따로 board읽고, comment 읽고. <- 처음이니 이것으로 가자!
	@Data
	public static class Read {
		private Integer bno;
		private String title;
		private String content;
		private String writer;
		private LocalDateTime writeTime;
		private Integer readCnt;
		private Integer goodCnt;
		private Integer badCnt;
		private Integer commentCnt;
		private List<Comment> comments;
	}
}
