package com.example.demo.entity;

import java.time.*;

import com.fasterxml.jackson.annotation.*;

import lombok.*;

@Getter
@Builder
@ToString
public class Comment {
	private Integer cno;
	private String content;
	private String writer;
	private LocalDateTime writeTime;
	@JsonIgnore
	private Integer bno;
	
	public Comment registerWriter(String loginId) {
		this.writer = loginId;
		return this;
	}
}
