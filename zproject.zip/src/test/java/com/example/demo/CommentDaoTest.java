package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.CommentDao;
import com.example.demo.entity.Comment;

@SpringBootTest
public class CommentDaoTest {
	@Autowired
	private CommentDao dao;
	
	//@Test
	public void saveTest() {
		dao.save(Comment.builder().bno(1).content("zzz").writer("winter").build());
	}
	
	//@Test
	public void findByBnoTest() {
		dao.findByBno(2);
	}
	
	//@Test
	public void findWriterTest() {
		assertEquals("winter", dao.findWriterById(4).get());
	}
	
	@Transactional
	//@Test
	public void deleteByCnoTest() {
		assertEquals(1, dao.deleteByCno(4));
	}
	
	@Transactional
	@Test
	public void deleteByBnoTest() {
		assertNotEquals(0, dao.deleteByBno(1));
	}
}
