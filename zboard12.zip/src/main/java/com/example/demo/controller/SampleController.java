package com.example.demo.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SampleController {
	
	// MVC 방식은 백도 프론트도 자바. 자바 객체를 바로 보내면 된다.
	@GetMapping("/sample1")
	public ModelAndView sample1() {
		// sample1은 화면의 이름 -> sample1.html
		return new ModelAndView("job1").addObject("서버의 응답");
	}
	
	// forward : 컨트롤러가 뷰를 띄운다. 사용자가 요청한 작업을 시작해서 처리 후 결과 페이지를 출력한다.
	//			일련의 연속된 작업 : 주소가 바뀌지 않는다.
	//			현재 사이트 외부로 forward 불가능
	// redirect : 다른 주소로 이동(새로운 작업, 주소가 바뀐다)
	@GetMapping("/sample2")
	public ModelAndView sample2() {
		return new ModelAndView("/test/job2");
	}
	
	// sample3로 들어오면 /example/job3로 forward하시오
	@GetMapping("/sample3")
	public ModelAndView sample3() {
		Map<String, String> map = new HashMap<>();
		map.put("username", "spring");
		map.put("password", "1234");
		return new ModelAndView("/example/job3").addObject("map", map);
	}
	
	// sample4로 들어오면 "홍길동", 20 학생 객체를 생성한 다음
	// job4로 포워드. 출력하시오
	
	@GetMapping("/sample4")
	public ModelAndView sample4() {
		Student s = new Student("홍길동", 20);
		return new ModelAndView("/job4").addObject("student", s); // (이름, 객체)
		// forward : job4.html + student
	}
	
	// 학생 정보 입력
	// REST 방식의 경우는 POST/student/add
	// MVC 방식의 경우는 화면을 보여주고 입력을 처리하자
	
	@GetMapping("/student/add")
	public ModelAndView add() {
		return new ModelAndView("/add");
	}
	@PostMapping("student/add")
	public ModelAndView add(@ModelAttribute Student student) {
		System.out.println(student);
		return new ModelAndView("redirect:/student/read");
	}
	
	@GetMapping("/student/read")
	public ModelAndView read() {
		// forward 방식은 연속된 작업. 데이터가 이어진다.
		// redirect는 새로운 작업의 시작.
		return new ModelAndView("/read");
	}
}
