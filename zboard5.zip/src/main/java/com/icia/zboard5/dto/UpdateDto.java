package com.icia.zboard5.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UpdateDto {
	private Integer bno;
	private String title;
	private String content;
}
