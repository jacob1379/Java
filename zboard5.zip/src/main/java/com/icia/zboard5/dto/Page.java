package com.icia.zboard5.dto;

import java.util.List;

import com.icia.zboard5.entity.Board;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class Page {
	private Integer pageno;
	private Integer pagesize;
	private Integer totalcount;
	private List<Board> boardList;
}
