package com.icia.zboard5.controller;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.math.NumberUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.icia.zboard5.dto.Page;
import com.icia.zboard5.service.BoardService;

@WebServlet("/board/all")
public class ListController extends HttpServlet {
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json; charset=utf-8");
		
		String str = request.getParameter("pageno");
		int pageno = NumberUtils.toInt(str,1);
		
		BoardService service = BoardService.getInstance();
		Page page = service.list(pageno);
		
		String json = new ObjectMapper().writeValueAsString(page);
		response.getWriter().print(json);
	}
}
