package com.icia.zboard5.controller;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.math.NumberUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.icia.zboard5.entity.Board;
import com.icia.zboard5.service.BoardService;

@MultipartConfig
@WebServlet("/board")
public class ReadController extends HttpServlet {
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String str = request.getParameter("bno");
		int bno = NumberUtils.toInt(str, 0);
		
		BoardService service = BoardService.getInstance();
		Optional<Board> board = service.read(bno);
		
		// 작업 결과에 따라 적절한 상태코드와 MIME 타입을 지정해 출력 (MIME,이메일에서 파일 첨부하는 것 등)
		// 만약 board가 null이라면 404보내기
		// board가 있다면 200dp json보내기
		if(board.isEmpty()) {
			// 문법은 스프링가면 바뀐다. 작업이 실패한 적절한 상태코드를 보내야한다.
			response.setContentType("text/plain; charset=utf-8");
			response.setStatus(HttpServletResponse.SC_CONFLICT);
			response.getWriter().print("글을 찾을 수 없습니다");
		} else { // 성공인지 실패인지
			response.setContentType("application/json; charset=utf-8");
			String json = new ObjectMapper().writeValueAsString(board.get());
			response.getWriter().print(json);			
		}
	}
}
