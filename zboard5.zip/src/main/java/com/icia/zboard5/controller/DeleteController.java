package com.icia.zboard5.controller;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.math.NumberUtils;

import com.icia.zboard5.service.BoardService;

@WebServlet("/board/delete")
public class DeleteController extends HttpServlet {
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String str = request.getParameter("bno");
		int bno = NumberUtils.toInt(str, 0);
		
		BoardService service = BoardService.getInstance();
		boolean result = service.delete(bno);
		
		response.setContentType("text/plain; charset=utf-8");
		if(result==false) {
			response.setStatus(HttpServletResponse.SC_CONFLICT);
			response.getWriter().print("글을 찾을 수 없습니다");
		} else { // 성공인지 실패인지
			response.getWriter().print(bno + "빈글을 삭제하였습니다.");
		}
	}
}
