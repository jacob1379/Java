package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.access.AccessDeniedHandler;

import com.example.demo.security.*;


// WebSecurityConfigurerAdapter 기반 설정은 스프링 시큐리티 5.7에서 deprecated

@SuppressWarnings("deprecation")
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled=true, securedEnabled=true, jsr250Enabled=true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired	// 로그인을 위한 사용자 정보를 읽어오는 메소드를 제공하는 인터페이스
	private UserDetailsService service;
	@Autowired	// 403을 처리하는 객체
	private AccessDeniedHandler accessDeniedHandler;
	@Autowired	// 로그인 성공했을 때 후속 조치를 담당하는 객체
	private LoginSuccessHandler loginSuccessHandler;
	
	// DaoAuthenticationProvider : DB를 이용한 인증 처리를 담당하는 객체
	//	 - UserDetailsService가 DB 작업 수행
	//	 - UserDetailsService가 사용자 정보를 이용해 UserDetails 객체를 생성
	// UserDetails와 클라이언트가 입력한 정보와 대조해 인증 및 인가 처리
	@Bean
	public DaoAuthenticationProvider getAuthenticationProvider() {
		DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
		daoAuthenticationProvider.setUserDetailsService(service);
		daoAuthenticationProvider.setPasswordEncoder(passwordEncoder);
		return daoAuthenticationProvider;
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// csrf(웹 페이지 위조를 방지하기 위한 기술.. 필수.. 개발할 때 귀찮아) 끄기 싫음
		// 403예외가 발생하면 accessDeniedHandler를 불러라
		http.csrf().disable().exceptionHandling().accessDeniedHandler(accessDeniedHandler);
		
		// formLogin : 백이 로그인 화면을 이용한 일반적인 로그인 활성화
		// 로그인에 성공하면 loginsuccessHandler 객체 실행
		http.formLogin().successHandler(loginSuccessHandler);
	
		http.logout().logoutUrl("/logout").logoutSuccessUrl("/");
	}
}
