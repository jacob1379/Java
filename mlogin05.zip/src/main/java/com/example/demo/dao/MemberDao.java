package com.example.demo.dao;

import java.util.Optional;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.example.demo.entity.Member;

@Mapper
public interface MemberDao {
	@Insert("insert into member values(#{username}, #{password}, #{irum}, #{email}, #{birthday})")
	public Integer save(Member member);
	
	@Select("select * from member where username=#{username} and rownum<=1")
	public Optional<Member> findById(String username);
}
