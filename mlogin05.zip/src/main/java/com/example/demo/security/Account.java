package com.example.demo.security;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

// UserDetails : 사용자 정보와 권한 정보를 저장하는 표준
// UserDtailsService : DB에서 읽어와 UserDetails를 생성하는 표준

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Account implements UserDetails {
	// username, password, 권한목록
	private String username;
	private String password;
	
	// ArrayLisst -> List -> Collection
	// HashMap -> Map -> Collection
	@Getter
	private Collection<GrantedAuthority> authorities;
	
	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public String getUsername() {
		return username;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() { // 비밀번호 유효기간 유무
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}
}
