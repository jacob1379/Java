package com.example.demo.security;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.MemberDao;
import com.example.demo.dao.RoleDao;
import com.example.demo.entity.Member;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class MemberUserDetailsService implements UserDetailsService {
	private final MemberDao memberDao;
	private final RoleDao roleDao;
	
	@Transactional(readOnly=true)
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		//memberDao에서 findById를 해서 값이 있으면 m에 대입, 없으면 예외가 발생
		Member member = memberDao.findById(username).orElseThrow(()->new UsernameNotFoundException("not found"));
		Account account = Account.builder().username(member.getUsername()).password(member.getPassword()).build();
		
		/*
		 * Collection<GrantedAuthority> authorities; List<String> 
		 * list = roleDao.findByUsername(username);
		 * for(String str:list) {
		 * authorities.add(new SimpleGrantedAuthority(str)); }
		 * account.setAuthorities(authorities);
		 * return account;
		 */
		
		Collection<GrantedAuthority> authorities = roleDao.findByUsername(username).stream().map(rolename->new SimpleGrantedAuthority(rolename)).collect(Collectors.toList());
		account.setAuthorities(authorities);
		return account;           //위와 같은 코드
	}
}
