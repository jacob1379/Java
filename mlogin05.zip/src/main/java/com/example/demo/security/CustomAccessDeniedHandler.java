package com.example.demo.security;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import org.springframework.security.access.*;
import org.springframework.security.web.access.*;
import org.springframework.stereotype.*;

// 권한없음이 발생했을 때 /error/e403으로 유도할 AccessDenialHandler
@Component
public class CustomAccessDeniedHandler implements AccessDeniedHandler {
	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
		// 서블릿에서 redirect 하는 방법 -> localhost:8087/index?error=403
		response.sendRedirect("/index?error=403");
	}
}
