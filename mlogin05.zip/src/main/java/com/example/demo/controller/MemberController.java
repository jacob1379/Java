package com.example.demo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.Member;
import com.example.demo.service.MemberService;

@Validated
@Controller
public class MemberController {
	@Autowired
	private MemberService service;
	
	// 루트 페이지
	@GetMapping({"/", "/index"})
	public String index() {
		return "/index";
	}
	
	// 회원 가입
	@PreAuthorize("isAnonymous()")
	@GetMapping("/join")
	public String join() {
		return "/join";
	}
	
	@PreAuthorize("isAnonymous()")
	@PostMapping("/join")
	public String join(@Valid Member member, BindingResult bindingResult) {
		service.join(member);
		return "/login";
	}
	
	// 비로그인 접근 가능 페이지
	@PreAuthorize("isAnonymous()")
	@GetMapping("/find")	
	public String find() {
		return "/find";
	}
	
	// 로그인 접근 가능 페이지
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/write")
	public String write() {
		return "/write";
	}
	
	// 403을 발생 -> AccessDeniedHandler -> /index?error=403 , 로그인했는데 권한 없으면 403
	@Secured("ROLE_ADMIN")
	@GetMapping("/admin")
	public String admin() {
		return "/admin";
	}
}
