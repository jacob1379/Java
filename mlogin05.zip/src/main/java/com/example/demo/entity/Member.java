package com.example.demo.entity;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class Member {
	private String username;
	private String password;
	private String irum;
	private String email;
	@DateTimeFormat(pattern="yyyy-MM-dd") // 없으면 날짜 못받음.
	private LocalDate birthday;
}

// /member/join?username=spring&password=1234&nai=20&birthday=1999-10-10
// spring을 String으로 username에 담는다.
// 1234를 String으로 password에 담는다.
// 20을 Integer로 nai에 담는다.
// 1999-10-10을 LocalDate로 birthday에 담는다.

// 스프링은 거대한 단일 프레임워크가 아니라 자잘 자잘한 부품들의 조립품
// 스프링이 프론트로부터 데이터를 입력받는다 : PropertyEditor 인터페이스
//		스프링은 PropertyEditor 구현체를 약 10개 정도 가지고 있다.
//		날짜로 바꿔주는 PropertyEditor는 없다.
// 스프링이 프론트에게 작업 결과를 출력한다 : MessageConverter 인터페이스
