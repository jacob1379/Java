package com.example.demo.entity;

import java.time.*;

import lombok.*;

@Getter
@Builder
@ToString
public class Board {
	@Setter
	private Integer bno;
	private String title;
	private String content;
	private String writer;
	private LocalDateTime writeTime;
	private Integer readCnt;
	private Integer goodCnt;
	private Integer badCnt;
	private Integer commentCnt;
	
	public Board registerWriter(String loginId) {
		this.writer=loginId;
		return this;
	}
}
