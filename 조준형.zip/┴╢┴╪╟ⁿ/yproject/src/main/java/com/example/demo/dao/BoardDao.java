package com.example.demo.dao;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.dto.BoardDto;
import com.example.demo.dto.BoardDto.ForList;
import com.example.demo.entity.Board;

@Mapper
public interface BoardDao {
	
	public Integer save(Board board);

	public Integer count(String writer);

	public List<ForList> findAll(Map<String, Object> map);

	public Optional<String> findWriterById(Integer bno);

	public Integer update(Board board);

	public Optional<BoardDto.Read> findById(Integer bno);

	public Integer deleteById(Integer bno);
}
