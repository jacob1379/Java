package com.example.demo.controller;

import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.example.demo.dto.RestResponse;
import com.example.demo.exception.BoardNotFoundException;
import com.example.demo.exception.JobFailException;

@ControllerAdvice
public class BoardControllerAdvice {
	@ExceptionHandler(BoardNotFoundException.class)
	public ResponseEntity<RestResponse> bNFEHandler() {
		return ResponseEntity.status(HttpStatus.CONFLICT).body(new RestResponse("FAIL", "게시물을 찾을 수 없습니다", null));
	}
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<RestResponse> cNFEHandler() {
		return ResponseEntity.status(HttpStatus.CONFLICT).body(new RestResponse("FAIL", "게시물을 찾을 수 없습니다", null));
	}
	
	// JobFailException은 예외 정보가 필요하다 : e.getMessage()
	@ExceptionHandler(JobFailException.class)
	public ResponseEntity<RestResponse> jNFEHandler() {
		return ResponseEntity.status(HttpStatus.CONFLICT).body(new RestResponse("FAIL", "게시물을 찾을 수 없습니다", null));
	}
	
	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<RestResponse> mNFEHandler() {
		return ResponseEntity.status(HttpStatus.CONFLICT).body(new RestResponse("FAIL", "잘못된 입력입니다", null));
	}
}
