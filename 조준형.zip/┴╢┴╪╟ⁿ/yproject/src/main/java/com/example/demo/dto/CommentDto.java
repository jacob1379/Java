package com.example.demo.dto;

import java.time.*;

import com.fasterxml.jackson.annotation.*;

import lombok.*;


@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class CommentDto {
	// 댓글 작성 : 내용, 댓글번호, 글쓴이, 글쓴시간
	// 댓글 읽기 : 내용, 댓글번호, 글쓴이, 글쓴시간
	// 댓글에서 bno를 빼는 방법
	// 1. select * from comments; -> entity로 읽어와 @JsonIgnore를 사용
	// 2. select 번호, 내용, 글쓴이, 글쓴시간 from comments; -> dto로 읽어온다
	// 댓글 삭제 : 댓글번호, 글번호, 글쓴이
	@Data
	public static class Read {
		private Integer cno;
		private String content;
		private String writer;
		@JsonFormat(pattern="yyyy-MM-dd")
		private LocalDateTime writeTime;
	}
}







