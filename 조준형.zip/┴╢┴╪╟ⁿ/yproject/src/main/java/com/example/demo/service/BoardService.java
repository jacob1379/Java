package com.example.demo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BoardDao;
import com.example.demo.dao.CommentDao;
import com.example.demo.dto.BoardDto;
import com.example.demo.dto.BoardDto.Page;
import com.example.demo.dto.BoardDto.Read;
import com.example.demo.dto.CommentDto;
import com.example.demo.entity.Board;
import com.example.demo.exception.BoardNotFoundException;
import com.example.demo.exception.JobFailException;

@Service
public class BoardService {
	@Autowired
	private BoardDao boardDao;
	@Autowired
	private CommentDao commentDao;
	
	@Value("${zproject.pagesize}")
	private Integer pagesize;

	public Board write(BoardDto.Write dto, String loginId) {
		Board board = dto.toEntity().addWriter(loginId);
		boardDao.save(board);
		return board;
	}
	
	// 글읽기 : 글이 없으면 409(BNFE). 글이 있고 글쓴이가 아니면 조회수 증가
	public Read read(Integer bno, String username) {
		BoardDto.Read dto = boardDao.findById(bno).orElseThrow(()->new BoardNotFoundException());
		List<CommentDto.Read> comments = commentDao.findByBno(bno);
		dto.setComments(comments);
		if(username!=null && username.equals(dto.getWriter())==false) {
			boardDao.update(Board.builder().bno(bno).readCnt(1).build());
			dto.setReadCnt(dto.getReadCnt()+1);
		}
		return dto;
	}
	
	// 글목록 : 글이 없으면 빈 목록
//	public BoardDto.Page list(Integer pageno, String writer) {
//		Integer totalcount = boardDao.count(writer);
//		Integer start = (pageno-1) * pagesize + 1;
//		Integer end = start * pagesize - 1;
//		
//		Map<String,Object> map = new HashMap<>();
//		map.put("start", start);
//		map.put("end", end);
//		map.put("writer", writer);
//		return new Page(pageno,pagesize,totalcount,boardDao.findAll(map));
//	}
	
	// 글변경 : 실패 - 글이 없다(BoardNotFoundException), 글쓴이가 아니다(JobFailException)
	public Board update(BoardDto.Update dto, String loginId) {
		String writer = boardDao.findWriterById(dto.getBno()).orElseThrow(() -> new BoardNotFoundException());
		if(writer.equals(loginId)==false)
			throw new JobFailException("변경 권한이 없습니다");
		Board board = dto.toEntity();
		boardDao.update(board);
		return board;
	}
	
	// 글삭제 : 실패 - 글이 없다(BNFE), 글쓴이가 아니다(JFE)
	public Integer delete(Integer bno, String loginId) {
		String writer = boardDao.findWriterById(bno).orElseThrow(()->new BoardNotFoundException());
		if(writer.equals(loginId)==false)
			throw new JobFailException("변경 권한이 없습니다");
		return boardDao.deleteById(bno);
	}

	public Page list( BoardDto.ListInput dto) {
		// Page : pageno, pagesize, totalcount, 글들
		Integer count = boardDao.count(dto.getWriter());
		// pageno 1->1, 2->11, 3->21...
		Integer start = (dto.getPageno()-1)*pagesize+1;
		Integer end = start+pagesize-1;
		
		// 마이바티스의 파라미터는 1개만 가능. 여러 파라미터는 map이나 객체로 넘기는 것이 원칙
		Map<String, Object> map = new HashMap<>();
		map.put("start", start);
		map.put("end", end);
		map.put("writer", dto.getWriter());
		List<BoardDto.ForList> boardList = boardDao.findAll(map);
		return new BoardDto.Page(dto.getPageno(), pagesize, count, boardList);
	}
}
