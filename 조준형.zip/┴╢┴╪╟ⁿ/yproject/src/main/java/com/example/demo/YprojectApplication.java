package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class YprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(YprojectApplication.class, args);
	}
	// @Component : 스프링이 빈을 생성 -> componentScan -> 프로젝트의 기본 패키지
	// @Bean : 프로그래머가 빈을 생성 -> 가져다 사용하는 라이브러리 클래스들
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

}
