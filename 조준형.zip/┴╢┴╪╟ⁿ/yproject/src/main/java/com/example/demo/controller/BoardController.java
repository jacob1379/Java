package com.example.demo.controller;

import java.security.Principal;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.BoardDto;
import com.example.demo.dto.RestResponse;
import com.example.demo.entity.Board;
import com.example.demo.service.BoardService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.v3.oas.annotations.Operation;
import springfox.documentation.annotations.ApiIgnore;

@Validated
@RestController
public class BoardController {
	// 글쓰기
	@Autowired
	private BoardService service;
	
	@Operation(summary="1.글 읽기", description="게시판 글 읽기")
	@ApiResponses({
		@ApiResponse(code=200, response=RestResponse.class, message="result : Read DTO"), 
		@ApiResponse(code=409, response=RestResponse.class, message="오류 메시지") 
	})
	@ApiImplicitParam(name="bno", value="글번호", required=true, dataTypeClass=Integer.class)
	// 사용자 인증 정보를 담은 객체는 Authentication -> 비로그인이어도 존재
	// Principal은 아이디만 들어있고 비로그인이면 null
	@GetMapping(value="/board", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> read(@RequestParam @NotNull(message="글번호는 필수입력입니다") Integer bno, @ApiIgnore Principal principal) {
		String loginId = principal==null? null : principal.getName();
		BoardDto.Read dto = service.read(bno, loginId);
		return ResponseEntity.ok(new RestResponse("OK", dto, null));
	}
	
	@PreAuthorize("isAuthenticated()")
	@Operation(summary="2.글 변경", description="게시판 글 변경")
	@ApiImplicitParams({
		@ApiImplicitParam(name="bno", value="글번호", required=true, dataTypeClass=Integer.class),
		@ApiImplicitParam(name="title", value="제목", required=true, dataTypeClass=String.class),
		@ApiImplicitParam(name="content", value="내용", required=true, dataTypeClass=String.class),
	})
	@ApiResponses({
		@ApiResponse(code=200, response=RestResponse.class, message="result: 이동할 주소"), 
		@ApiResponse(code=409, response=RestResponse.class, message="오류 메시지") 
	})
	@PutMapping(value="/board", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> update(@ModelAttribute @Valid BoardDto.Update dto, BindingResult bindingResult, @ApiIgnore Principal principal) {
		service.update(dto, principal.getName());
		return ResponseEntity.ok(new RestResponse("OK", dto.getBno() + "번 글을 변경했습니다", "/board/read?bno="+dto.getBno()));
	}
	
	@PreAuthorize("isAuthenticated()")
	@Operation(summary="3.글 삭제", description="게시판 글 삭제")
	@ApiResponses({ 
		@ApiResponse(code=200, response=RestResponse.class, message="result : 이동할 주소"), 
		@ApiResponse(code=409, response=RestResponse.class, message="오류 메시지") 
	})
	@ApiImplicitParam(name="bno", value="글번호", required=true, dataTypeClass=Integer.class)
	@DeleteMapping(value="/board", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> delete(@RequestParam  @NotNull(message="글번호는 필수입력입니다") Integer bno, @ApiIgnore Principal principal) {
		service.delete(bno, "summer");
		return ResponseEntity.ok(new RestResponse("OK", bno +"번 글을 삭제했습니다", "/board/list"));
	}
	
	@Operation(summary="4.글 목록", description="페이지 번호에 해당하는 boardList, pageno, pagesize, totalcount 리턴")
	@ApiImplicitParams({
		@ApiImplicitParam(name="pageno", value="글번호(기본값은 1)", required=false, dataTypeClass=Integer.class),
		@ApiImplicitParam(name="writer", value="글쓴이(선택 입력)", required=true, dataTypeClass=String.class)
	})
	
	 @ApiResponses({
	 @ApiResponse(code=200, response=RestResponse.class, message="result : Page DTO"),
	 @ApiResponse(code=409, response=RestResponse.class, message="오류") })
	 
	@GetMapping(path="/board/all", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> list(@ModelAttribute @Valid BoardDto.ListInput dto, BindingResult br) {
		BoardDto.Page result = service.list(dto);
		return ResponseEntity.ok(new RestResponse("OK", result, null));
	}
	
	// 어노테이션은 클래스의 자식뻘. 모든 어노테이션은 value라는 기본값 필드를 가진다
	@PreAuthorize("isAuthenticated()")
	@Operation(summary="5.글 쓰기", description="게시판 글 작성")
	@ApiImplicitParams({
		@ApiImplicitParam(name="title", value="제목", required=true, dataTypeClass=String.class),
		@ApiImplicitParam(name="content", value="내용", required=true, dataTypeClass=String.class),
	})
	@ApiResponses({
		@ApiResponse(code=200, response=RestResponse.class, message="url은 글을 읽을 수 있는 주소"), 
		@ApiResponse(code=409, response=RestResponse.class, message="오류 메시지") 
	})
	@PostMapping(value="/board/new", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RestResponse> write(@ModelAttribute @Valid BoardDto.Write dto, BindingResult bindingResult, @ApiIgnore Principal principal) {
		Board board = service.write(dto, principal.getName());
		return ResponseEntity.ok(new RestResponse("OK", board, "/board/read?bno=" + board.getBno()));
	}
	
}