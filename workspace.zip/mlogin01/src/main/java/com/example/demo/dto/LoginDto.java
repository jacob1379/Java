package com.example.demo.dto;

import javax.validation.constraints.NotEmpty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

// fasade 패턴 : 표준 <-- 구현체
//				slf4j <-- logback, log4j2
//		javax.validation(jsr-380) <-- hibernate(검증, JPA)

@Getter
@Setter
@ToString
public class LoginDto {
	// @NotNull은 빈입력을 허용. 숫자에 사용
	@NotEmpty(message = "아이디는 필수 입력입니다.") // 검증 어노테이션, 글자에 사용
	private String username;
	@NotEmpty(message = "비밀번호는 필수 입력입니다.")
	private String password;
}