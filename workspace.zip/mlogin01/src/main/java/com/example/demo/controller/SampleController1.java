package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SampleController1 {
	@GetMapping("/sample1")
	public String sample1() {
		// 로그인 여부, ~님 환영합니다.
		return "/sample1";
	}
}
