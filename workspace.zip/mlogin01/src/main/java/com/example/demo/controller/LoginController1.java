package com.example.demo.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.dto.LoginDto;

// http는 상태가 없다 -> 사용자를 구별 못한다. -> 사용자 정보를 저장 못한다.
// 사용자 정보를 저장하기 위한 기술 -> HttpSession
// HttpSession을 사용하는 대표적인 예 : login, 장바구니
// 그러면 http가 상태가 없는데 어떻게 세션을 사용자마다 세션 하나씩 관리할 수 있나?
// Cookie를 사용한다.
// Cookie가 뭔데?
// 서버가 내 컴퓨터 특정 폴더에 저장하는 텍스트 파일
// Cookie의 대표적인 사용예는?
// 방문했던 링크 보라색
// www.naver.com에서 받은 모든 쿠키는 www.naver.com에 접근하면 자동 전송된다.
// 세션은 쿠키에 의존한다 -> 안전하지 않다. 세션이 없을 때 생성

@Controller
public class LoginController1 {
	// 리턴값 String은 뷰의 이름
	@GetMapping("/login1")
	public String login() { //모델이 필요 없어서 modelandview 쓰지 않고 string 사용
		return "/login1";
	}
	
	// 사용자 정보를 담고있는 객체를 Command 객체
	// 스프링은 커맨드 객체를 생성할 때 기본 생성자로 생성 후 세터로 값 입력
	@PostMapping("/login1")
	public String login(LoginDto dto, HttpSession session) {
		// 아이디가 spring, 비밀번호가 1111이라면 로그인 성공 처리를 하겠다.
		session.setAttribute("username", dto.getUsername());
		System.out.println(dto);
		// http는 상태가 없다.(stateless) -> 메모리가 없다... 치매
		// 사용자 정보를 저장하는 서버측 기술 : HttpSession(ex, 로그아웃시 장바구니 날아감), 데이터베이스(비쌈,유료)(장바구니 안날아감)
		return "redirect:/sample1";
	}
}
