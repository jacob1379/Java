package com.icia.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.extern.slf4j.Slf4j;

// 자동으로 생성되는 스프링 부트 프로젝트 시작 파일
@Slf4j
@SpringBootApplication
public class ZzboardApplication {

	public static void main(String[] args) {
		// slf4j는 로깅 표준
		// slf4j의 구현체 중에 logback +log4jdbc를 사용
		// 모든 로깅 구현체들(slf4j 표준에 따른다)의 사용법은 동일하다.
		// 이런 방식을 facade 패턴이라고 한다.
		log.trace("trace 레벨 출력입니다.");
		log.debug("debug 레벨 출력입니다.");
		log.info("info 레벨 출력입니다.");
		log.warn("warn 레벨 출력입니다.");
		log.error("error 레벨 출력입니다.");
		SpringApplication.run(ZzboardApplication.class, args);
	}

}
