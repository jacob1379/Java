package com.icia.web.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

// 클래스 내부에 클래스를 넣을 수 있다 -> 내부 클래스
// 내부 클래스를 이용해서 DTO를 정리하자 : BoardDto 내부에 DTO들을 담는다
// 그래서 new BoardDto.ReadDto() 이렇게 호출하려함.

// 1. 우선 BoardDto객체를 못만들게 하자
// 2. 내부 클래스의 객체를 만드려면 외부 클래스의 객체가 존재해야 한다.
//		내부 클래스를 static으로 만들면 외부 클래스의 객체가 필요없다.

@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class BoardDto {
	@Getter
	public static class ListDto {
		private Integer bno;
		private String title;
		private String nickname;
		private Integer readCnt;
	}
	
	@Getter
	public static class ReadDto {
		private Integer bno;
		private String title;
		private String content;
		private String nickname;
		private Integer readCnt;
		@JsonFormat(pattern="yyyy-MM-dd hh:mm:ss")
		private LocalDateTime writeTime;
	}
}
