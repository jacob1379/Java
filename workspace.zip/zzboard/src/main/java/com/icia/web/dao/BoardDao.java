package com.icia.web.dao;

import java.util.List;

import com.icia.web.entity.Board;

//DAO : Data Access Object. 보통 db 작업을 담당하는 객체를 말한다.
//MyBatis에서 DAO를 만드는 방법
//1. 인터페이스
//2. 인터페이스 + xml mapper 파일
//3. 클래스 + xml 설정 파일

public interface BoardDao {
	public List<Board> findAll();
}
