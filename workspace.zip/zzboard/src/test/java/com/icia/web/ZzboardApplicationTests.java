package com.icia.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZzboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
