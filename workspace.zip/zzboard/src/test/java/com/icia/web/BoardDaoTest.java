package com.icia.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.icia.web.dao.BoardDao;

@SpringBootTest
public class BoardDaoTest {
	@Autowired
	BoardDao dao;
	
	public void findAllTest() {
		dao.findAll().forEach(b->System.out.println(b));
	}
}
