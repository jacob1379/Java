package com.example.demo.dao;

import java.util.List;
import java.util.Optional;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.dto.BoardDto;
import com.example.demo.entity.Board;

// DAO에 입력은 Entity, 출력은 DTO도 가능
@Mapper
public interface BoardDao {
	public List<BoardDto.ListDto> findAll();
	
	public Optional<BoardDto.ReadDto> findById(Integer bno);
	
	public Integer save(Board board);
}
