package com.example.demo.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class BoardDto {
	@Data
	public static class ListDto {
		private Integer bno;
		private String title;
		private String nickname;
		private Integer readCnt;
	}
	@Data
	public static class ReadDto {
		private Integer bno;
		private String title;
		private String content;
		private String nickname;
		private Integer readCnt;
		@JsonFormat(pattern="yyyy-MM-dd")
		private LocalDateTime writeTime;
	}
	public static class WriteDto {
		
	}
	public static class UpdateDto {
	
	}
	public static class DeleteDto {
	
	}
}
