package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.BoardDao;
import com.example.demo.entity.Board;

@SpringBootTest
public class BoardDaoTest {
	@Autowired
	BoardDao dao;
	
	//@Test
	public void findAllTest() {
		dao.findAll().forEach(b->System.out.println(b));
	}
	
	//@Test
	public void findByIdTest() {
		assertEquals(true, dao.findById(1).isPresent());
		assertEquals(true, dao.findById(1111).isEmpty());
	}
	//@Transactional
	@Test
	public void saveTest() {
		Board board = Board.builder().title("sss").content("bbdfb").nickname("작ss가").password("112").build();
		assertEquals(1, dao.save(board)); 	
	}
}
