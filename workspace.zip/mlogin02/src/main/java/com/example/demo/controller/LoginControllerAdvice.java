package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

// 컨트롤러 어드바이스는 컨트롤러의 일종(예외를 처리하는 컨트롤러)
// 컨트롤러는 주소가 일치하면 동작
// 컨트롤러 어드바이스는 예외가 일치하면 동작
@ControllerAdvice
public class LoginControllerAdvice {
	// 코딩할 때 클래스 이름을 적어야하는 경우 ~.class라고 적는다.
	@ExceptionHandler(BindException.class) // 예외가 발생하면 아래를 실행해라
	public ModelAndView loginExceptionHandler(BindingResult br) {
		List<String> messages = new ArrayList<>();
		br.getAllErrors().forEach(e->messages.add(e.getDefaultMessage()));
		return new ModelAndView("/error").addObject("messages",messages);
		//System.out.println("====== 어드바이스 동작 ======");
	}
}
