package com.example.demo.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.dto.LoginDto;

//@Vallidated : 스프링 빈 검증 어노테이션
//@Valid : 자바표준 빈 검증 어노테이션 -> 커맨드 객체일 경우만 검증 가능

@Controller
public class LoginController {
	@GetMapping("/login1")
	public String login() {
		return "/login1";
	}
	
	// 사용자 입력값을 검증. 어디서 할까? 스프링 커맨드 객체에서 수행
	// 검증에 실패한 경우 오류 메시지를 담는 BindingResult 객체가 만들어진다.
	@PostMapping("/login1")
	public String login(@Valid LoginDto dto, BindingResult bindingResult) throws BindException {
	// 스프링 검증 실패 : BindingException
	// BindingResult에 오류 메시지가 들어있다면 BindingException을 실행시켜라
	
		bindingResult.getAllErrors().forEach(a->System.out.println(a.getDefaultMessage()));
		if(bindingResult.hasErrors())
			throw new BindException(bindingResult);
		return "redirect:/sample1";
	}
}
