package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.BoardDao;
import com.example.demo.entity.Board;

@SpringBootTest
public class BoardDaoTest {
	@Autowired
	BoardDao dao;
	
	//@Transactional
	//@Test
	public void saveTest() {
		Board board = Board.builder().title("aaa").content("bbb").writer("ccc").password("1111").build();
		assertEquals(1, dao.save(board));
	}
	//@Test
	public void findAllTest() {
		dao.findAll().forEach(b->System.out.println(b));
	}
	//@Test
	public void findById() {
		assertEquals(true, dao.findById(1).isPresent());
		assertEquals(true, dao.findById(111).isEmpty());
	}
	//@Transactional
	//@Test
	public void update() {
		Board board = Board.builder().bno(1).title("xxx").content("yyy").build();
		assertEquals(1, dao.update(board));
	}
	//@Transactional
	//@Test
	public void delete() {
		assertEquals(1, dao.deleteById(1));
	}
	//@Test
	public void increaseReadCnt() {
		assertEquals(1, dao.increaseReadCnt(1));
	}
	@Test
	public void findPasswordTest() {
		assertEquals("1111", dao.findPassword(1).get());
	}
}
