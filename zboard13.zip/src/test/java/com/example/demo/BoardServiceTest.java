package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dto.BoardDto.DeleteDto;
import com.example.demo.dto.BoardDto.UpdateDto;
import com.example.demo.dto.BoardDto.WriteDto;
import com.example.demo.entity.Board;
import com.example.demo.service.BoardService;

@SpringBootTest
public class BoardServiceTest {
	@Autowired
	BoardService service;
	
	//@Transactional
	//@Test
	public void writeTest() {
		WriteDto dto = WriteDto.builder().title("xxx").content("yyy").writer("sss").password("aaaa").build();
		Board result = service.save(dto);
		//System.out.println(result);
		assertEquals(2, result.getBno());
	}
	
	//@Test
	public void listTest() {
		service.findAll().forEach(b->System.out.println(b));
	}
	
	//@Test
	public void readTest() {
		System.out.println(service.findById(1));
		assertEquals(true, service.findById(1).isPresent());
		assertEquals(true, service.findById(122).isEmpty());
	}
	//@Transactional
	@Test
	public void updateTest() {
		UpdateDto d1 = UpdateDto.builder().bno(111).title("rkrrk").content("dkdjf").password("1234").build();
		UpdateDto d2 = UpdateDto.builder().bno(2).title("rkrrk").content("dkdjf").password("1234").build();
		UpdateDto d3 = UpdateDto.builder().bno(1).title("rkrrk").content("dkdjf").password("1111").build();
		assertEquals(false, service.update(d1));
		assertEquals(false, service.update(d2));
		assertEquals(true, service.update(d3));
	}
	@Transactional
	//@Test
	public void deleteTest() {
		DeleteDto d1 = DeleteDto.builder().bno(111).password("7777").build();
		DeleteDto d2 = DeleteDto.builder().bno(3).password("7777").build();
		DeleteDto d3 = DeleteDto.builder().bno(3).password("2222").build();
		assertEquals(false, service.deleteById(d1));
		assertEquals(false, service.deleteById(d2));
		assertEquals(true, service.deleteById(d3));
	}
}
