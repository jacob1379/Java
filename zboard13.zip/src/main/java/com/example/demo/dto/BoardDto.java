package com.example.demo.dto;

import java.time.LocalDateTime;


import javax.validation.constraints.NotEmpty;

import com.example.demo.entity.Board;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor(access=AccessLevel.PACKAGE)
public class BoardDto {
	@Data
	@Builder
	public static class WriteDto {
		@NotEmpty // 필수 입력
		private String title;
		private String content;
		private String writer;
		private String password;
		public Board toEntity() {
			return Board.builder().title(title).content(content)
					.writer(writer).password(password).build();
		}
	}
	@Getter
	@ToString
	public static class ListDto {
		private Integer bno;
		private String title;
		private String writer;
		private Integer readCnt;
	}
	@Getter
	public static class ReadDto {
		private Integer bno;
		private String title;
		private String content;
		private String writer;
		private LocalDateTime writeTime;
		private Integer readCnt;
	}
	@Data
	@Builder
	public static class UpdateDto {
		private Integer bno;
		private String title;
		private String content;
		private String password;
		public Board toEntity() {
			return Board.builder().title(title).content(content).bno(bno).build();
		}
	}
	@Data
	@Builder
	public static class DeleteDto {
		private Integer bno;
		private String password;
	}
	
}
